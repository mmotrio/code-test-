const test = require('tap').test;
// const JSONRPC = require('../../src/util/jsonrpc');

test('constructor', t => {
    t.end();
});

test('sendRemoteRequest', t => {
    t.end();
});

test('sendRemoteNotification', t => {
    t.end();
});

test('didReceiveCall', t => {
    t.end();
});
