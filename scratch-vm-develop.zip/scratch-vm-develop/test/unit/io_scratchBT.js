const test = require('tap').test;
// const ScratchBT = require('../../src/io/scratchBT');

test('constructor', t => {
    t.end();
});

test('requestPeripheral', t => {
    t.end();
});

test('connectPeripheral', t => {
    t.end();
});

test('sendMessage', t => {
    t.end();
});

test('didReceiveCall', t => {
    t.end();
});
